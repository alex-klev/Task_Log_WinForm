import sqlite3 as sl
import os

# conn = sl.connect("classnost_db_PyQt5.db") # Создаем подключение
# conn = sl.connect("db\TaskLogDb.db") # Создаем подключение
"""
# Создаем подключение (Объединение компонентов пути)
conn = sl.connect(os.path.join("db", "TaskLogDb.db"))
# Получаем курсор
cursor = conn.cursor()
# Включение поддержки внешних ключей
conn.execute("PRAGMA foreign_keys = ON;")
"""

"""
# Создаем подключение (Объединение компонентов пути)
# conn = sl.connect(os.path.join("dataBase", "classnost_db_PyQt5.db"))
conn = sl.connect(os.path.join("dataBase", "classnost_db_PyQt5_dynamic_report.db"))
# Получаем курсор
cursor = conn.cursor()
# Включение поддержки внешних ключей
conn.execute("PRAGMA foreign_keys = ON;")
"""


#! ### Проверка наличия данных ###
class ExistData:
    """Объект для проверки наличия записи в БД"""
    @staticmethod
    def exist_data(table_name: str, first_column_name: str, first_value: str, second_value: str = None, second_column_name: str = None) -> bool:        
        with sl.connect(os.path.join("db", "TaskLogDb.db")) as conn:
            # Получаем курсор
            cursor = conn.cursor()
            # Включение поддержки внешних ключей
            conn.execute("PRAGMA foreign_keys = ON;")
            
            try:
                # Получаем все данные из таблицы
                # execute принимает в качестве параметров кортеж. Запятая нужна после self.value
                
                """
                if second_value is None and second_column_name is None:
                    data = cursor.execute("SELECT COUNT (" + first_column_name + ") FROM " + table_name + " "
                                        "WHERE " + first_column_name + " = ?", (first_value,)).fetchall()
                else:
                    data = cursor.execute("SELECT COUNT (" + first_column_name + ") FROM " + table_name + " "
                                        "WHERE " + first_column_name + " = ? AND " + second_column_name + " = ?", (first_value, second_value)).fetchall()
                """
                
                if second_value is None and second_column_name is None:
                    data = cursor.execute("SELECT 1 FROM " + table_name + " "
                                        "WHERE " + first_column_name + " = ?", (first_value,)).fetchall()
                else:
                    data = cursor.execute("SELECT 1 FROM " + table_name + " "
                                        "WHERE " + first_column_name + " = ? AND " + second_column_name + " = ?", (first_value, second_value)).fetchall()
                
                # print((cursor.fetchall()))
                # data = cursor.fetchall()
                # print(data)
            except sl.Error as err:
                print("Ошибка при работе с базой данных ", err)
                return [('',)]
            else:
                # Если данные найдены, возвращаем True, иначе False
                # return data is not None
                return len(data) > 0


#! ### Удаление данных ###
class DeleteData:
    """Удаление данных"""
    @staticmethod
    def delete_data(table_name: str, first_column_name: str, first_value: str, second_value: str = None, second_column_name: str = None) -> None:
        with sl.connect(os.path.join("db", "TaskLogDb.db")) as conn:
            # Получаем курсор
            cursor = conn.cursor()
            # Включение поддержки внешних ключей
            conn.execute("PRAGMA foreign_keys = ON;")
            
            try:
                # execute принимает в качестве параметров кортеж. Запятая нужна после data
                # cursor.execute("INSERT INTO table_name (abcd) VALUES(?)", (data,))
                
                # Удаление записи из таблицы
                if second_value is None and second_column_name is None:
                    cursor.execute("DELETE FROM " + table_name + " WHERE " + first_column_name + " = ?", (first_value,))
                else:
                    cursor.execute("DELETE FROM " + table_name + " WHERE " + first_column_name + " = ? AND " + second_column_name + " = ?", (first_value, second_value))
            except sl.Error as err:
                print("Ошибка при работе с базой данных ", err)
            else:
                # Выполняем транзакцию
                conn.commit()


#! ### Справочник руководителей ###
class BossesCatalogDb(DeleteData, ExistData):
    """Справочник руководителей"""
    def __init__(self, **kwargs) -> None:
        self.data_id = kwargs.get('p0')  # id записи
        self.fio = kwargs.get('p1')  # Ф.И.О. руководителя
        self.current_datetime = kwargs.get('p2')  # Текущая дата и время
    
    def load_data(self):
        """Загружаем данные из таблицы"""
        with sl.connect(os.path.join("db", "TaskLogDb.db")) as conn:
            # Получаем курсор
            cursor = conn.cursor()
            # Включение поддержки внешних ключей
            conn.execute("PRAGMA foreign_keys = ON;")
            
            try:
                # получаем все данные из таблицы bosses
                # execute принимает в качестве параметров кортеж. Запятая нужна после self.user_id
                """
                cursor.execute("SELECT opros_id, user_id, total_score, investment_term, result_type, description, current_datetime FROM opros "
                                "WHERE user_id = ?", (self.user_id,))
                """
                
                data = cursor.execute("SELECT data_id, fio FROM bosses "
                                      "WHERE fio <> 'нет данных' ").fetchall()
                
                # data = cursor.execute("SELECT data_id, fio FROM bosses ").fetchall()
                
                # print((cursor.fetchall()))
                # data = cursor.fetchall()
                # print(data)
            except sl.Error as err:
                print("Ошибка при работе с базой данных ", err)
                return [('',)]  # Возвращаем пустой список кортежа
            else:
                return data
    
    def delete_data(self) -> None:
        # Вызываем метод базового класса
        super().delete_data(table_name="bosses", first_column_name="data_id", first_value=self.data_id)
    
    def insert_data(self) -> None:
        with sl.connect(os.path.join("db", "TaskLogDb.db")) as conn:
            # Получаем курсор
            cursor = conn.cursor()
            # Включение поддержки внешних ключей
            conn.execute("PRAGMA foreign_keys = ON;")
            
            try:
                # execute принимает в качестве параметров кортеж. Запятая нужна после data
                # cursor.execute("INSERT INTO table_name (abcd) VALUES(?)", (data,))       
                
                # Вставляем новую запись в таблицу bosses
                cursor.execute("INSERT INTO bosses (data_id, fio, create_datetime) VALUES (?, ?, ?)",
                                (self.data_id, self.fio, self.current_datetime))
            except sl.Error as err:
                print("Ошибка при работе с базой данных ", err)
            else:
                # Выполняем транзакцию
                conn.commit()
    
    def update_data(self) -> None:
        with sl.connect(os.path.join("db", "TaskLogDb.db")) as conn:
            # Получаем курсор
            cursor = conn.cursor()
            # Включение поддержки внешних ключей
            conn.execute("PRAGMA foreign_keys = ON;")
            
            try:
                # Обновляем запись в таблице bosses
                cursor.execute("UPDATE bosses SET fio = ?, create_datetime = ? "
                            "WHERE data_id = ?",
                            (self.fio, self.current_datetime, self.data_id))
            except sl.Error as err:
                print("Ошибка при работе с базой данных ", err)
            else:
                # Выполняем транзакцию
                conn.commit()
    
    def save(self) -> None:
        """Сохранение данных"""
        # Проверка наличия данных
        # Вызываем констуктор базового класса        
        data_exist = super().exist_data(table_name="bosses", first_column_name="fio", first_value=self.fio)
        # print(data_exist[0][0])  # 1
        # print(data_exist)
        
        if data_exist == [('',)]:
            return [('',)]
        
        if data_exist:
            self.update_data()
        else:
            self.insert_data()